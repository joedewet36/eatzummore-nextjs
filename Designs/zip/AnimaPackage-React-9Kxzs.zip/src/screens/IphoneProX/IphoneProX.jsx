import React from "react";
import "./style.css";

export const IphoneProX = () => {
  return (
    <div className="iphone-pro-x">
      <div className="div">
        <div className="overlap">
          <div className="overlap-group">
            <div className="ellipse" />
            <h1 className="text-wrapper">Login</h1>
            <img className="group" alt="Group" src="/img/group-767.png" />
            <img className="chevron-left" alt="Chevron left" src="/img/chevron-left.svg" />
          </div>
          <div className="text-wrapper-2">email</div>
        </div>
        <div className="div-wrapper">
          <a className="text-wrapper-3" href="mailto:yourmail@mail.com" rel="noopener noreferrer" target="_blank">
            yourmail@mail.com
          </a>
        </div>
        <div className="overlap-2">
          <div className="text-wrapper-4">your password</div>
          <img className="vector" alt="Vector" src="/img/vector.svg" />
        </div>
        <div className="frame">
          <div className="text-wrapper-5">Login</div>
        </div>
        <div className="frame-2">
          <div className="text-wrapper-6">Don’t have an account?</div>
          <div className="text-wrapper-7">Register</div>
        </div>
        <div className="text-wrapper-8">password</div>
        <div className="text-wrapper-9">Forgot Password</div>
        <div className="dark-mode-false-type">
          <div className="right-side">
            <img className="battery" alt="Battery" src="/img/battery.png" />
            <img className="wifi" alt="Wifi" src="/img/wifi.svg" />
            <img className="mobile-signal" alt="Mobile signal" src="/img/mobile-signal.svg" />
          </div>
          <img className="left-side" alt="Left side" src="/img/left-side.png" />
        </div>
      </div>
    </div>
  );
};
