export { IphoneProX } from "./IphoneProX";
