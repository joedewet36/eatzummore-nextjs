declare const useSvgSizing: (baseWidth: number, baseHeight: number, scale?: number) => Array<number>;
export default useSvgSizing;
