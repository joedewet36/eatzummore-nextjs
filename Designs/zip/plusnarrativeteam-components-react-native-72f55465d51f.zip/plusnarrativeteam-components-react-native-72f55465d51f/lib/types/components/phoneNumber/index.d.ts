import React from 'react';
declare const PhoneNumber: React.FC<{
    label: string;
    placeHolder: string;
}>;
export default PhoneNumber;
