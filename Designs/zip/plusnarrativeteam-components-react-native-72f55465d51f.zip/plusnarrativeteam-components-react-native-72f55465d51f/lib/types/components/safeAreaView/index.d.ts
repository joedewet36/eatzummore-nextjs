import React from 'react';
import { ViewProps } from 'react-native';
declare const SafeAreaView: React.FC<ViewProps>;
export default SafeAreaView;
