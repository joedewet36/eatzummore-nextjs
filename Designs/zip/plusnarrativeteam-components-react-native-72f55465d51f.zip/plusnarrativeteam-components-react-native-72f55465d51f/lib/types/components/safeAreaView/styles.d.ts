export declare const hasNotch: boolean;
declare const _default: {
    container: {
        flex: number;
        paddingTop: number | undefined;
    };
};
export default _default;
