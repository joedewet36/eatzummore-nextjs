import React from 'react';
declare type Props = {
    /**
     * Some cool test to show.
     */
    text: string;
};
declare const Template: React.FC<Props>;
export default Template;
