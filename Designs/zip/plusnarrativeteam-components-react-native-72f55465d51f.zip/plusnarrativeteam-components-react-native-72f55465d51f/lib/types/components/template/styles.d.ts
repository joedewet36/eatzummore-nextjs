declare const _default: {
    container: {
        flex: number;
        alignItems: "center";
        justifyContent: "center";
    };
    text: {
        color: string;
    };
};
export default _default;
