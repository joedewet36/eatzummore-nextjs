import { TextStyle } from 'react-native';
import { TypographyVariant, Theme } from '@plus-components/types/theme';
declare const _default: (variant: TypographyVariant, theme: Theme) => TextStyle;
export default _default;
