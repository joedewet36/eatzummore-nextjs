export declare const safelyParse: (jsonString: string) => any;
declare const _default: {
    safelyParse: (jsonString: string) => any;
};
export default _default;
