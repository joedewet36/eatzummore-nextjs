export declare const applyAlpha: (color: string, alpha: number) => string;
declare const _default: {
    applyAlpha: (color: string, alpha: number) => string;
};
export default _default;
