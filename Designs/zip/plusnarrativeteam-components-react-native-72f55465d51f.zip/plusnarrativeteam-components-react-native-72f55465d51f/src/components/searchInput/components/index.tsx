import React from 'react';
import { View, FlatList } from 'react-native';

export const ListItem: React.FC = () => {
  return <View />;
};

export const List: React.FC = () => {
  return <View />;
};
