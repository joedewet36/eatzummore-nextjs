import './components/template';
import './components/typography';
import './components/avatar';
import './components/pill';
import './components/button';
import './components/textInput';
import './components/searchInput';
import './components/phoneNumber';

import './misc/colors';
